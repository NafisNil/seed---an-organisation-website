<div class="elementor-element elementor-element-cf5b455 elementor-align-left elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="cf5b455" data-element_type="widget" data-widget_type="icon-list.default">
    <div class="elementor-widget-container">
      <ul class="elementor-icon-list-items">
        <li class="elementor-icon-list-item">
          <span class="elementor-icon-list-icon">
            <i aria-hidden="true" class="fas fa-copyright"></i>
          </span>
          <span class="elementor-icon-list-text">2024 BSEED ,All rights Reserved</span>
        </li>
      </ul>
      <div id="google_translate_element"></div>
    </div>
  </div>