<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Focus extends Model
{
    //
    protected $fillable = ['photo', 'desc', 'title'];
}
